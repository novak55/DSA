﻿// pch.cpp: zdrojový soubor odpovídající předkompilované hlavičce; nezbytný k tomu, aby kompilace byla úspěšná

#include "pch.h"

// Tento soubor lze obvykle ignorovat, ale pokud používáte předkompilované hlavičky, uložte si ho.
